#include <stdio.h>
#include <stdlib.h>
#include "llist.h"

/**
 * Appropriate Comments are added to Functions, can be used for Analysis/Checking.
 * main() and printlist() with a sample text is available and commented out.
 **/

LLIST createLList()
{
    struct NODE* head;
    head = NULL;
    LLIST list = head;
    // head = NULL;
    return list;
} 

int searchList(LLIST H, int k)
{
    LLIST list = H;
    while (list != NULL)
    {
        if(list->value == k)
            return 1;
        list = list->next;
    }
    return 0;
}

LLIST insertAtFront(LLIST H, int k)
{
    struct NODE* nd;
    nd = (struct NODE*)malloc(sizeof(struct NODE *));
    nd->value = k;
    nd->next = H;
    H = nd;
    // printf("Element: %d inserted at Front of the Linked List.\n", k);
    return H;
}

LLIST insertAtEnd(LLIST H, int k)
{
    struct NODE* node;
    node = (struct NODE *)malloc(sizeof(struct NODE *));
    node->value = k;
    node->next = NULL;
    LLIST list = H;
    if(H==NULL)
    {
        list = node;
        return list;
    }
    while (list->next != NULL)
        list = list->next;
    list->next = node;
    // printf("Element: %d inserted at End of the Linked List.\n", k);
    return H;
}

LLIST deleteFromFront(LLIST H, int *k)
{
    *k = H->value;
    LLIST list = H->next;
    // printf("Element: %d deleted from Front of the Linked List.\n", *k);
    return list;
}

LLIST deleteFromEnd(LLIST H, int *k)
{
    if (H == NULL)
        return NULL;
 
    if (H->next == NULL) {
        free(H);
        return NULL;
    }
 
    // Find the second last node
    struct NODE* second_last = H;
    while (second_last->next->next != NULL)
        second_last = second_last->next;
 
    // Delete last node
    *k = second_last->next->value;
    free(second_last->next);
 
    // Change next of second last
    second_last->next = NULL;
 
    return H;
}

LLIST deleteList(LLIST H, int k)
{
    LLIST temp = H;
    while(H->value==k)
    {
        H = H->next;
        break;
    }
    while(temp->next!=NULL)
    {
        if(temp->next->value == k)
        {
            temp->next = temp->next-> next;
            break;
        }
        else
        {
            temp = temp->next;
        }
    }
    // printf("%d element deleted from list.(if present)\n",k);
    return H;
}
void printList(LLIST H)
{
    LLIST temp = H;
    while(temp!=NULL)
    {
        printf("%d ", temp->value);
        temp = temp->next;
    }
    printf("\n");
}
 
// int main()
// {
//     LLIST head = createLList();
//     printList(head);
//     head = insertAtFront(head, 1);
//     printList(head);
//     head = insertAtFront(head, 2);
//     printList(head);
//     head = insertAtFront(head, 3);
//     printList(head);
//     head = insertAtFront(head, 4);
//     printList(head);
//     head = insertAtFront(head, 5);
//     printList(head);
//     head = insertAtEnd(head, 100);
//     printList(head);
//     printf("%d\n",searchList(head,4));
//     printList(head);
//     int *k;
//     k = (int *)malloc(sizeof(int));
//     head = deleteList(head,100);
//     printList(head);
//     head = deleteFromFront(head,k);
//     printf("%d\n",*k);
//     printList(head);
//     head = deleteFromEnd(head,k);
//     printf("%d\n",*k);
//     printList(head);
// }