// // #ifndef QUEUE_H
// #define QUEUE_H
#include "llist.h"
struct Queue
{
    LLIST qu;
    int size;
};
typedef struct Queue QUEUE;
QUEUE createQueue();
int isEmptyQueue(QUEUE Q);
QUEUE enqueue(QUEUE Q, int k);
QUEUE dequeue(QUEUE Q, int *k);
// #endif