#include <stdio.h>
#include <stdlib.h>
#include "stack.h"
#include "llist.h"

STACK createStack()
{
    STACK stack;
    stack.size = 0;
    stack.st = createLList();
    return stack;
}

int isEmptyStack(STACK S)
{
    return (S.size) == 0;
}

STACK push(STACK S, int k)
{
    S.st = insertAtFront(S.st, k);
    S.size++;
    return S;
}

STACK pop(STACK S, int *k)
{
    int a = -1;
    S.st = deleteFromFront(S.st,&a);
    S.size--;
    *k = a;
    return S;
}

// void printStack(STACK S)
// {
//     LLIST temp;
//     temp = S.st;
//     while(temp!=NULL)
//     {
//         printf("%d ", temp->value);
//         temp = temp->next;
//     }
//     printf("\n");
// }

// int main()
// {
//     int k = -1;
//     STACK S = createStack();
//     S = push(S,1);
//     printStack(S);
//     S = push(S,2);
//     printStack(S);
//     S = push(S,3);
//     printStack(S);
//     S = pop(S,&k);
//     printf("%d\n", k);
//     printStack(S);
// }