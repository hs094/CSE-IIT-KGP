#include <stdio.h>
#include <stdlib.h>
#include "ufind.h"

UNION_FIND createUF(int n)
{
    UNION_FIND ret;
    ret.n = n;
    ret.idx = -1;
    ret.sets = (NODE_PTR)malloc(n * sizeof(NODE_PTR));
    return ret;
}

UNION_FIND makeSetUF(UNION_FIND F, int x, int *i)
{
    F.idx++;
    (F.sets+F.idx)->value = x;
    (F.sets+F.idx)->parent = (F.sets+F.idx);
    (F.sets+F.idx)->rank = 1;
    *i = F.idx;
    return F;
}

NODE_PTR findUF(UNION_FIND  F,  int  i)
{
    NODE_PTR ptr = F.sets+i;
    while(ptr->parent!=ptr) 
        ptr = ptr->parent;
    return ptr;
}

void unionUF(UNION_FIND F, int i, int j)
{
    NODE_PTR one = findUF(F, i);
    NODE_PTR two = findUF(F, j);
    if(one->rank < two->rank)
    {
        one->parent = two;
        one->rank += two->rank;
    }
    if(one->rank > two->rank)
    {
       two->parent = one;
       one->rank += two->rank;   
    }
}

// int main()
// {
//     UNION_FIND uf = createUF(16);
//     int index_store = 0;
//     uf = makeSetUF(uf,34,&index_store);
//     printf("%d\n", index_store);
//     uf = makeSetUF(uf,19,&index_store);
//     printf("%d\n", index_store);
//     uf = makeSetUF(uf,5, &index_store);
//     printf("%d\n", index_store);
//     uf = makeSetUF(uf,23, &index_store);
//     printf("%d\n", index_store);
//     uf = makeSetUF(uf,11,&index_store);
//     printf("%d\n", index_store);
//     uf = makeSetUF(uf,47, &index_store);
//     printf("%d\n", index_store);
//     uf = makeSetUF(uf,47,&index_store);
//     printf("%d\n", index_store);
//     uf = makeSetUF(uf,9, &index_store);
//     printf("%d\n", index_store);
//     uf = makeSetUF(uf,28,&index_store);
//     printf("%d\n", index_store);
//     printf("%d\n",(uf.sets+2)->value);
//     printf("%d\n", index_store);
//     printf("%d\n",(uf.sets+2)->rank);
//     printf("%d\n", index_store);
//     unionUF(uf,1,2);
// }