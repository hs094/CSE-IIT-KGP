const int max_size = 100;
struct Heap
{
    int *arr;
    int curr_size;
};
typedef struct Heap HEAP;
HEAP createHeap();
int findMin(HEAP H);
HEAP extractMin(HEAP H);
HEAP insertHeap(HEAP H, int k);
int isFullHeap(HEAP H);
int isEmptyHeap(HEAP H);
void swap(int *i,int *j);