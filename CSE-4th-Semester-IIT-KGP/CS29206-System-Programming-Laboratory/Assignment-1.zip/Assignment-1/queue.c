#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "queue.h"
#include "llist.h"


QUEUE createQueue()
{
    QUEUE list;
    list.qu = createLList();
    list.size = 0;
    return list;
}

int isEmptyQueue(QUEUE Q)
{
    return Q.size == 0 ? 1 : 0;
}

QUEUE enqueue(QUEUE Q, int k)
{
    Q.qu = insertAtEnd(Q.qu, k);
    Q.size++;
    return Q;
}

QUEUE dequeue(QUEUE Q, int *k)
{
    Q.qu = deleteFromFront(Q.qu, k);
    Q.size--;
    return Q;  
}

// int front(QUEUE Q)
// {
//     if(Q.size == 0)
//         return INT_MIN;
//     return Q.qu->value;
// }
// int back(QUEUE Q)
// {
//     if(Q.size == 0)
//         return INT_MIN;
//     while(Q.qu->next !=NULL)
//         Q.qu = Q.qu->next;
//     return Q.qu->value;
// }
// void printStack(QUEUE S)
// {
//     LLIST temp;
//     temp = S.qu;
//     while(temp!=NULL)
//     {
//             printf("%d ", temp->value);
//             temp = temp->next;
//     }
//     printf("\n");
// }
// int main()
// {
//     QUEUE list = createQueue(); 
//     // printList(list.qu);
//     list = enqueue(list,1);
//     // printList(list.qu);
//     list = enqueue(list,2);
//     // printList(list.qu);
//     list = enqueue(list,3);
//     // printList(list.qu);
//     printStack(list);
//     int k;
//     list = dequeue(list,&k);
//     printf("%d\n", k);
//     printStack(list);
// }