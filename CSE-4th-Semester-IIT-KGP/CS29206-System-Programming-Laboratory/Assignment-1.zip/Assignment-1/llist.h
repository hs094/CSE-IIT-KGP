#ifndef LLIST_H
#define LLIST_H
struct NODE
{
    int value;  // value stored in the node
    struct NODE *next; // pointer to the next node in the linked list
};
// typedef struct NODE NODE;
typedef struct NODE* LLIST; // pointer of nodes ,i.e, the Linked List
LLIST createLList(); 
int searchList(LLIST H, int k);
LLIST insertAtFront(LLIST H, int k);
LLIST insertAtEnd(LLIST H, int k);
LLIST deleteFromFront(LLIST H, int *k);
LLIST deleteFromEnd(LLIST H, int *k);
LLIST deleteList(LLIST H, int k);
// void printList(LLIST H);
#endif

