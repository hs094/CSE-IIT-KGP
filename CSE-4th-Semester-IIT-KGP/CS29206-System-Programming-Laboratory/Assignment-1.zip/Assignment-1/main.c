#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <limits.h>
#include <stdarg.h>
#include "graph.h"

const int MAX_SIZE = 100;

int main()
{
    printf("**** CS29206 : Systems Programming Assignment ****\n");
    printf("** By Hardik Pravin Soni * 20CS30023 **\n");
    printf("Please Enter the Name of the File Storing Information Regarding the Graph: ");
    const char* filename;
    filename = (char *)malloc(MAX_SIZE*sizeof(char));
    scanf("%s",filename);
    // File name of the .txt file containing weighted undirected graph
    GRAPH graph = readGraph(filename);
    BFS(graph);
    DFS(graph);
    MST(graph);
    return 0;
}