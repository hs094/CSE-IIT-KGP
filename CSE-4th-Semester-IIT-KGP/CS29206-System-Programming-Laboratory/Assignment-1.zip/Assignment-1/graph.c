#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "graph.h"
#include "llist.h"
#include "queue.h"
#include "stack.h"
#include "ufind.h"
typedef struct arr
{
    int start, end, cost;

} info;
// Reading the Graph from the Given File Name
// n: Number of Vertices in the GRAPH
// m: Number of Edges in the GRAPH
// adjacency_matrix: The adjacency matrix Representation of the graph
GRAPH readGraph(char *File_Name)
{
    GRAPH G;
    G.n = 0;
    G.m = 0;
    G.adjacency_matrix = NULL;
    FILE *fp = fopen(File_Name, "r");

    if (fp == NULL)
    {
        printf("WARNING::::%s.txt cannot be opened\n", File_Name);
        return G;
    }
    fscanf(fp, "%d", &G.n);
    fscanf(fp, "%d", &G.m);

    G.adjacency_matrix = (int **)malloc((G.n) * sizeof(int *));
    for (int i = 0; i < G.n; i++)
    {
        G.adjacency_matrix[i] = (int *)malloc((G.n) * sizeof(int));
        for (int j = 0; j < G.n; j++)
            G.adjacency_matrix[i][j] = 0;
    }
    int u = -1, v = -1, w = -1;
    for (int i = 0; i < G.m; i++)
    {
        fscanf(fp, "%d%d%d", &u, &v, &w);
        G.adjacency_matrix[u][v] = w;
        G.adjacency_matrix[v][u] = w;
    }
    return G;
}

// QUEUE Data Structure using Dynamic Library
//  Prints Nodes in the BFS Traversal Order
//  Ignore Weights while doing the Traversal
//  Time Complexity : O(V+E)

void BFS(GRAPH G)
{
    if (G.n == 0)
    {
        printf("The Graph is Empty.\n");
    }
    else
    {
        QUEUE q = createQueue();
        int *visited;
        visited = (int *)malloc((G.n) * sizeof(int));
        for (int i = 0; i < G.n; i++)
            visited[i] = 0;
        q = enqueue(q, 0);
        visited[0] = 1;
        int current_Vertex = 0;
        printf("*** BREADTH FIRST ORDER TRAVERSAL:- ***\n");
        while (!isEmptyQueue(q))
        {
            q = dequeue(q, &current_Vertex);
            printf("%d ", current_Vertex);
            for (int i = 0; i < G.n; i++)
            {
                if (G.adjacency_matrix[current_Vertex][i] && !visited[i])
                {
                    q = enqueue(q, i);
                    visited[i] = 1;
                }
            }
        }
        printf("\n\n");
    }
}

// STACK Data Strcutre present in the Dynamic Library invoked
// Prints all the Nodes in the Depth First Search Traveral Order
//  Ignores Weights while doing the Traversal

void DFS(GRAPH G)
{
    if (G.n == 0)
    {
        printf("The Graph is Empty.\n");
    }
    else
    {
        STACK s = createStack();
        int *visited;
        visited = (int *)malloc((G.n) * sizeof(int));
        for (int i = 0; i < G.n; i++)
            visited[i] = 0;
        s = push(s, 0);
        int current_Vertex = 0;
        visited[0] = 1;
        printf("*** DEPTH FIRST ORDER SEARCH TRAVERSAL:- ***\n");
        printf("%d ", current_Vertex);
        while (!isEmptyStack(s))
        {
            s = pop(s, &current_Vertex);
            if (!visited[current_Vertex])
            {
                visited[current_Vertex] = 1;
                printf("%d ", current_Vertex);
            }
            for (int i = 0; i < G.n; i++)
            {
                if ((G.adjacency_matrix[current_Vertex][i]) && !visited[i])
                {
                    s = push(s, i);
                }
            }
        }
        printf("\n\n");
    }
}

// UNION FIND Strcutre present in the Dynamic Library invoked
// Prints all the Edges with their vertices and weigths on a single line
// This is Followed by the Weight of the MST's Edge

void MST(GRAPH G)
{
    if (G.n == 0)
    {
        printf("The Graph is Empty.\n");
    }
    else
    {
        printf("*** KRUSKAL's MINIMUM SPANNING TREE ALGORITHM ***\n");
        int cost = 0;
        // int cnt_edges = 0;
        UNION_FIND uf = createUF(G.n);
        info arr[G.m];
        int *index = (int *)malloc(sizeof(int));
        for (int i = 0; i < G.n; i++)
            uf = makeSetUF(uf, i, index);
        // int start,end;
        // int k=0;
        // while(cnt_edges < G.n)
        // {
        //     int min_ = INT_MAX;
        //     int max_ = 0;
        //     for(int i=0;i<G.n;i++)
        //     {
        //         for(int j=i+1;j<G.n;j++)
        //         {
        //             if(findUF(uf,i)!=findUF(uf,j) && G.adjacency_matrix[i][j]!=0 && G.adjacency_matrix[i][j]<min_ && G.adjacency_matrix[i][j]>max_)
        //             {
        //                 arr[k].start = i;
        //                 arr[k].end = j;
        //                 arr[k].cost = G.adjacency_matrix[i][j];
        //                 min_ = G.adjacency_matrix[i][j];
        //                 start = i;
        //                 end = j;
        //                 // printf("Edge No:- %d: (%d, %d, %d)\n",cnt_edges+1,start,end,min_);
        //             }
        //         }
        //     }
        //     unionUF(uf,start,end);
        //     cnt_edges++;
        //     cost+=min_;
        // }
        int k = 0;
        for (int i = 0; i < G.n; i++)
        {
            for (int j = i + 1; j < G.n; j++)
            {
                if (G.adjacency_matrix[i][j] != 0)
                {
                    arr[k].start = i;
                    arr[k].end = j;
                    arr[k++].cost = G.adjacency_matrix[i][j];
                }
            }
        }
        for (int i = 0; i < k; i++)
        {
            for (int j = i + 1; j < k; j++)
            {
                if (arr[j].cost < arr[i].cost)
                {
                    info t = arr[i];
                    arr[i] = arr[j];
                    arr[j] = t;
                }
            }
        }
        int l = 1;
        for (int i = 0; i < k; i++)
        {
            if (findUF(uf, arr[i].start) != findUF(uf, arr[i].end))
            {
                unionUF(uf, arr[i].start, arr[i].end);
                cost += arr[i].cost;
                printf("Edge #%d: %d %d %d\n", l, arr[i].start, arr[i].end, arr[i].cost);
                l++;
            }
            if (l == G.n)
                break;
        }
        printf("The Minimum Cost as Found by Kruskal's Minimum Spanning Tree is %d\n\n", cost);
    }
}

int main()
{
    char *filename = "file.txt";
    GRAPH G = readGraph(filename);
    BFS(G);
    DFS(G);
    MST(G);
}