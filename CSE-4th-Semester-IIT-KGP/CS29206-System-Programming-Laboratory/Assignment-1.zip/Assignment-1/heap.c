// A C Implementation of Min Heap using a Array of Max Size 100
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "heap.h"

HEAP createHeap()
{
    HEAP heap;
    heap.arr = (int *)malloc(0*sizeof(int));
    heap.curr_size = 0;
    return heap;
}

int findMin(HEAP H)
{
    if(H.curr_size <= 0)
        return INT_MAX;
    else
        return H.arr[0];
}

HEAP extractMin(HEAP H)
{
    if(isEmptyHeap(H))
        return createHeap();
    else if(H.curr_size == 1)
    {
        H.curr_size--;
        H.arr = NULL;
        return H;
    }
    HEAP heap = createHeap();
    heap.arr = (int *)malloc((H.curr_size-1)*sizeof(int));
    heap.curr_size = H.curr_size - 1;
    for(int i = 1; i < H.curr_size ;i ++)
        heap.arr[i-1] = H.arr[i];
    return heap;
}

HEAP insertHeap(HEAP H, int k)
{
    if(isFullHeap(H))
    {
        printf("ERROR:::THE HEAP IS FULL\n");
        return H;
    }
    H.curr_size++;
    int i = H.curr_size - 1;
    H.arr[i] = k;
  
    // Fix the min heap property if it is violated
    while (i != 0 && H.arr[(i-1)/2] > H.arr[i])
    {
       swap(&H.arr[i], &H.arr[(i-1)/2]);
       i = (i-1)/2;
    }
    return H;
}

int isFullHeap(HEAP H)
{
    return (H.curr_size == max_size) ? 1 : 0;
}

int isEmptyHeap(HEAP H)
{
    return (H.curr_size==0) ? 1 : 0;
}

void swap(int *i, int *j)
{
    int k = *i;
    *i = *j;
    *j = k;
}

