typedef struct graph
{
    /* data */
    int n; /* number of nodes in the graph */
    int m; /* number of edges in the graph */
    int **adjacency_matrix; /* adjecency matrix representing of the graph */
}GRAPH;
/*
    Method Signatures of all the Methods:- readGraph, BFS(Breadth First Search), DFS(Depth First Search) and MST(Kruskal's Minimum Spanning Tree Algorithm)
*/
GRAPH readGraph(char *FName);
void DFS(GRAPH G);
void BFS(GRAPH G);
void MST(GRAPH G);
int main();