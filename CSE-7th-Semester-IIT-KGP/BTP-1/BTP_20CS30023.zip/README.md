This format has been developed by Sarthak Jain (Email: sarthakjain939@gmail.com) for help in writing a thesis as per standards followed in IIT Kharagpur with help from thesis templates from www.sharelatex.com. 

Feel free to use this, improve and add your contribution to the KGP community. 

Cheers!
Sarthak