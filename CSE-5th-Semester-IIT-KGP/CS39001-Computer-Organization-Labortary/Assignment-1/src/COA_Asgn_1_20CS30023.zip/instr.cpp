Instruction subleq a, b, c
    Mem[b] = Mem[b] - Mem[a]
    if (Mem[b] <= 0)
        goto c