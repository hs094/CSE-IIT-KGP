subleq b, b
subleq a, Z
subleq Z, b
subleq Z, Z